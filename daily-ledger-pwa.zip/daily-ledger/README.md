# Daily Ledger — PWA

Track daily purchases and sales. Runs on Android and iOS as an installable app — no App Store required.

---

## Deploy in 5 minutes (Option A — Local Build)

### Prerequisites
- [Node.js 18+](https://nodejs.org) — download and install if you don't have it

### Step 1 — Install & Build

Open a terminal, navigate to this folder, and run:

```bash
npm install
npm run build
```

This creates a `dist/` folder with the compiled app.

### Step 2 — Deploy to Netlify

1. Go to **https://app.netlify.com/drop**
2. Drag the entire `dist/` folder onto the page
3. Netlify gives you a live URL instantly (e.g. `https://random-name.netlify.app`)

Done! Your app is live.

---

## Deploy in 10 minutes (Option B — GitHub + Netlify Auto-Build)

Use this if you don't have Node.js locally.

1. Push this entire folder to a **GitHub repo**
2. Go to **https://app.netlify.com** → "Add new site" → "Import an existing project"
3. Connect your GitHub repo
4. Netlify detects the `netlify.toml` and builds automatically
5. Every time you push changes, Netlify rebuilds

---

## Install on Android

1. Open the app URL in **Chrome**
2. Tap the **⋮ menu → "Add to Home screen"**
3. Tap **Add** — it appears on your home screen like a native app

---

## Install on iOS

1. Open the app URL in **Safari** (must be Safari, not Chrome)
2. Tap the **Share button** (box with arrow pointing up)
3. Scroll down and tap **"Add to Home Screen"**
4. Tap **Add** — the app icon appears on your home screen

> **iOS note:** Use iOS 16.4 or later for the best PWA experience.
> Data is stored in the browser's local storage and persists between sessions.

---

## Local Development

```bash
npm install
npm run dev
```

Opens at `http://localhost:5173` with hot reload.

---

## Tech Stack

- React 18 + Vite
- Recharts (bar charts)
- Service Worker (offline support)
- localStorage (data persistence)
