const CACHE = 'daily-ledger-v1'

// On install: take control immediately
self.addEventListener('install', () => self.skipWaiting())

// On activate: remove old caches
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))
    ).then(() => self.clients.claim())
  )
})

// Fetch strategy: serve from cache, update in background (stale-while-revalidate)
// Navigation requests always try network first so deploys propagate.
self.addEventListener('fetch', event => {
  const { request } = event

  // Skip non-GET and cross-origin requests
  if (request.method !== 'GET' || !request.url.startsWith(self.location.origin)) return

  if (request.mode === 'navigate') {
    // Page load: network first, fall back to cached shell
    event.respondWith(
      fetch(request)
        .then(res => {
          const clone = res.clone()
          caches.open(CACHE).then(c => c.put(request, clone))
          return res
        })
        .catch(() => caches.match(request).then(r => r || caches.match('/')))
    )
  } else {
    // Assets: cache first, then network
    event.respondWith(
      caches.match(request).then(cached => {
        const network = fetch(request).then(res => {
          caches.open(CACHE).then(c => c.put(request, res.clone()))
          return res
        })
        return cached || network
      })
    )
  }
})
